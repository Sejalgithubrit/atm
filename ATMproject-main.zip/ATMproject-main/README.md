# ATMproject
"Automated Teller Machine" - a web application where a Customer can get services of the Bank.

## Requirments
The system will be developed on a Windows machine using J2EE, JSP/HTML, and JDBC. 
