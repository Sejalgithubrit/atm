package com.atm.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.atm.springboot.Admintable;

public interface AdminRepository extends JpaRepository<Admintable, Integer>
{

}