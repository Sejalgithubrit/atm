package com.atm.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.atm.springboot.BranchDetails;

public interface BranchDetailsRepository extends JpaRepository<BranchDetails, Integer>
{

}