package com.atm.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.atm.springboot.LoginCredentials;

public interface LoginCredentialsRepository extends JpaRepository<LoginCredentials, Integer>
{

}