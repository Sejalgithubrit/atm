package com.atm.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.atm.springboot.Cheque;

public interface ChequeRepository extends JpaRepository<Cheque, Integer>
{

}